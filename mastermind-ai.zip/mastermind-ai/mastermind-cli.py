#!/usr/bin/env python3
"""
MASTERMIND AI - Ultimate Edition
Your Billionaire AI Assistant

Features:
- Multi-provider AI (Groq, Anthropic, OpenAI, Ollama)
- Code generation & execution
- Project scaffolding
- Web search integration
- Multi-agent orchestration
- Conversation memory
- Web interface
"""

import sys
import os

# Add to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from mastermind.core.cli import main

if __name__ == '__main__':
    main()