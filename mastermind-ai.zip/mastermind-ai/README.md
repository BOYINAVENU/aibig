# 💎 Mastermind AI - Ultimate Edition

Your billionaire AI assistant with unlimited power!

## 🚀 Features

✅ **Multi-Provider AI**: Groq, Anthropic, OpenAI, Ollama
✅ **Code Generation**: Complete projects with one command
✅ **Business Analysis**: Deep market insights
✅ **Project Scaffolding**: FastAPI, React, Full-stack templates
✅ **Code Execution**: Run and test generated code
✅ **Conversation History**: Never lose context
✅ **Auto-save Code**: Extract and save code blocks
✅ **Beautiful UI**: Rich terminal interface

## 📦 Installation

```bash
# Clone/Download the project
cd mastermind-ai

# Install dependencies
pip install -r requirements.txt

# Set your API key
export GROQ_API_KEY='your-key-here'