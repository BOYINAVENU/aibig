"""Mastermind AI - Ultimate CLI Engine"""
import os
import sys
import json
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax
from rich.progress import Progress
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
import click

console = Console()

class MastermindAI:
    """Ultimate AI Engine - All Providers + Advanced Features"""
    
    def __init__(self, provider="groq", model=None):
        self.config_dir = Path.home() / ".mastermind"
        self.config_dir.mkdir(exist_ok=True)
        self.history_file = self.config_dir / "history.jsonl"
        self.messages = []
        self.provider = provider
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Model configuration
        if model:
            self.current_model = model
        elif provider == "groq":
            self.current_model = "llama-3.3-70b-versatile"  # Most powerful!
        elif provider == "anthropic":
            self.current_model = "claude-sonnet-4-20250514"
        elif provider == "openai":
            self.current_model = "gpt-4-turbo-preview"
        elif provider == "ollama":
            self.current_model = "llama3.3:70b"
        else:
            self.current_model = "llama-3.3-70b-versatile"
    
    def chat(self, prompt: str, system_prompt: Optional[str] = None) -> str:
        """Send message to AI with optional system prompt"""
        
        if system_prompt:
            self.messages = [{"role": "system", "content": system_prompt}]
        
        self.messages.append({"role": "user", "content": prompt})
        
        try:
            if self.provider == "groq":
                response = self._chat_groq()
            elif self.provider == "anthropic":
                response = self._chat_anthropic()
            elif self.provider == "openai":
                response = self._chat_openai()
            elif self.provider == "ollama":
                response = self._chat_ollama()
            else:
                response = self._chat_groq()
            
            self._save_history(prompt, response)
            return response
            
        except Exception as e:
            return f"❌ Error: {str(e)}"
    
    def _chat_groq(self) -> str:
        """Groq - Fastest Inference"""
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            return "❌ Set GROQ_API_KEY environment variable"
        
        try:
            from groq import Groq
            client = Groq(api_key=api_key)
            
            response = client.chat.completions.create(
                model=self.current_model,
                messages=self.messages,
                temperature=0.7,
                max_tokens=32000,
                top_p=0.9
            )
            
            reply = response.choices[0].message.content
            self.messages.append({"role": "assistant", "content": reply})
            return reply
            
        except ImportError:
            return "❌ Install: pip install groq"
        except Exception as e:
            return f"❌ Groq error: {str(e)}"
    
    def _chat_anthropic(self) -> str:
        """Anthropic Claude - Most Capable"""
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            return "❌ Set ANTHROPIC_API_KEY"
        
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=api_key)
            
            # Extract system message if present
            system_msg = None
            user_messages = []
            for msg in self.messages:
                if msg["role"] == "system":
                    system_msg = msg["content"]
                else:
                    user_messages.append(msg)
            
            response = client.messages.create(
                model=self.current_model,
                max_tokens=64000,
                messages=user_messages,
                system=system_msg or "You are Mastermind AI, an expert coding assistant."
            )
            
            reply = response.content[0].text
            self.messages.append({"role": "assistant", "content": reply})
            return reply
            
        except Exception as e:
            return f"❌ Anthropic error: {str(e)}"
    
    def _chat_openai(self) -> str:
        """OpenAI GPT - Industry Standard"""
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return "❌ Set OPENAI_API_KEY"
        
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            
            response = client.chat.completions.create(
                model=self.current_model,
                messages=self.messages,
                temperature=0.7,
                max_tokens=4000
            )
            
            reply = response.choices[0].message.content
            self.messages.append({"role": "assistant", "content": reply})
            return reply
            
        except Exception as e:
            return f"❌ OpenAI error: {str(e)}"
    
    def _chat_ollama(self) -> str:
        """Ollama - Local Models"""
        try:
            import requests
            
            response = requests.post(
                "http://localhost:11434/api/chat",
                json={
                    "model": self.current_model,
                    "messages": self.messages,
                    "stream": False
                }
            )
            
            if response.status_code == 200:
                reply = response.json()["message"]["content"]
                self.messages.append({"role": "assistant", "content": reply})
                return reply
            else:
                return f"❌ Ollama error: {response.text}"
                
        except Exception as e:
            return f"❌ Ollama not running: {str(e)}\n\nStart with: ollama serve"
    
    def _save_history(self, prompt: str, response: str):
        """Save conversation to history"""
        try:
            with open(self.history_file, 'a', encoding='utf-8') as f:
                entry = {
                    "session_id": self.session_id,
                    "timestamp": datetime.now().isoformat(),
                    "provider": self.provider,
                    "model": self.current_model,
                    "prompt": prompt,
                    "response": response
                }
                f.write(json.dumps(entry) + '\n')
        except Exception as e:
            console.print(f"[yellow]Warning: Could not save history: {e}[/yellow]")
    
    def execute_code(self, code: str, language: str = "python") -> str:
        """Execute code safely"""
        if language == "python":
            try:
                # Create temp file
                temp_file = self.config_dir / f"temp_{self.session_id}.py"
                temp_file.write_text(code)
                
                # Execute
                result = subprocess.run(
                    [sys.executable, str(temp_file)],
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                
                output = result.stdout + result.stderr
                temp_file.unlink()
                return output
                
            except Exception as e:
                return f"Execution error: {str(e)}"
        else:
            return f"Language {language} not supported yet"
    
    def create_project(self, name: str, template: str = "fastapi"):
        """Generate complete project structure"""
        project_dir = Path.cwd() / name
        project_dir.mkdir(exist_ok=True)
        
        if template == "fastapi":
            self._create_fastapi_project(project_dir)
        elif template == "react":
            self._create_react_project(project_dir)
        elif template == "fullstack":
            self._create_fullstack_project(project_dir)
        
        return f"✓ Project '{name}' created at {project_dir}"
    
    def _create_fastapi_project(self, project_dir: Path):
        """Create FastAPI backend project"""
        files = {
            "main.py": '''from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "Welcome to your API"}

@app.get("/health")
def health_check():
    return {"status": "healthy"}
''',
            "requirements.txt": "fastapi>=0.104.0\nuvicorn>=0.24.0\npython-dotenv>=1.0.0\nsqlalchemy>=2.0.0",
            "README.md": f"# {project_dir.name}\n\nFastAPI backend\n\n## Run:\n```bash\npip install -r requirements.txt\nuvicorn main:app --reload\n```",
            ".env.example": "DATABASE_URL=sqlite:///./app.db\nSECRET_KEY=your-secret-key"
        }
        
        for filename, content in files.items():
            (project_dir / filename).write_text(content)


class REPL:
    """Advanced Interactive REPL"""
    
    def __init__(self, provider="groq", model=None):
        self.ai = MastermindAI(provider=provider, model=model)
        self.session = PromptSession(
            history=FileHistory(str(self.ai.config_dir / "repl_history.txt")),
            auto_suggest=AutoSuggestFromHistory()
        )
        self.auto_execute_code = False
    
    def run(self):
        """Run enhanced REPL"""
        self._print_banner()
        
        while True:
            try:
                text = self.session.prompt("\n💎 You: ").strip()
                
                if not text:
                    continue
                
                # Handle commands
                if text in ["/exit", "/quit", "/q"]:
                    console.print("\n[yellow]🚀 Go build the future![/yellow]\n")
                    break
                
                if text == "/help":
                    self._show_help()
                    continue
                
                if text == "/models":
                    self._show_models()
                    continue
                
                if text.startswith("/switch"):
                    provider = text.split()[1] if len(text.split()) > 1 else "groq"
                    self.ai.provider = provider
                    console.print(f"[green]✓ Switched to {provider}[/green]")
                    continue
                
                if text.startswith("/project"):
                    parts = text.split()
                    name = parts[1] if len(parts) > 1 else "myproject"
                    template = parts[2] if len(parts) > 2 else "fastapi"
                    result = self.ai.create_project(name, template)
                    console.print(f"[green]{result}[/green]")
                    continue
                
                # Enhanced prompts
                if text.startswith("/gen"):
                    text = f"""Generate a complete, production-ready, profitable project with:
1. Backend API (FastAPI/Flask with all endpoints)
2. Frontend UI (React/Next.js with modern design)
3. Database schema (PostgreSQL with migrations)
4. Authentication & authorization
5. Payment integration (Stripe)
6. Deployment config (Docker + cloud)
7. Monetization strategy
8. Marketing plan
9. Full documentation

Make it ready to launch and generate revenue. Provide ALL code files."""

                elif text.startswith("/analyze"):
                    text = f"""Conduct deep business analysis:
1. Market size & growth trends
2. Competitive landscape analysis
3. Revenue model options (SaaS, API, marketplace, etc.)
4. Technical architecture & stack
5. MVP features prioritization
6. Go-to-market strategy
7. Customer acquisition cost (CAC) estimates
8. Lifetime value (LTV) projections
9. Funding requirements
10. 18-month roadmap

Be specific and actionable."""

                elif text.startswith("/code"):
                    text += "\n\nProvide complete, production-ready code with error handling, logging, tests, and documentation."
                
                # Get AI response
                with console.status("[bold green]🧠 Thinking...", spinner="dots"):
                    response = self.ai.chat(text)
                
                # Display response
                console.print("\n")
                console.print(Panel(
                    Markdown(response),
                    title="[bold cyan]💎 Mastermind AI[/bold cyan]",
                    border_style="cyan",
                    padding=(1, 2)
                ))
                
                # Auto-extract and save code
                self._extract_code(response)
                
            except KeyboardInterrupt:
                continue
            except EOFError:
                break
            except Exception as e:
                console.print(f"\n[red]Error: {e}[/red]")
    
    def _print_banner(self):
        """Print startup banner"""
        banner = f"""
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║              💎 MASTERMIND AI - ULTIMATE EDITION 💎                  ║
║                                                                      ║
║  Provider: {self.ai.provider.upper():^20}  Model: {self.ai.current_model[:30]:<30} ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
"""
        console.print(banner, style="bold cyan")
        console.print("\n💡 [yellow]Commands:[/yellow] /gen | /analyze | /code | /project | /models | /help | /exit\n")
    
    def _show_help(self):
        """Show help"""
        help_text = """
[bold cyan]📚 MASTERMIND AI COMMANDS[/bold cyan]

[green]/gen[/green] <idea>          - Generate complete profitable project
[green]/analyze[/green] <business>  - Deep business analysis with metrics
[green]/code[/green] <request>      - Generate production-ready code
[green]/project[/green] <name> <template> - Create full project structure
[green]/models[/green]              - Show available models
[green]/switch[/green] <provider>   - Switch AI provider (groq/anthropic/openai/ollama)
[green]/help[/green]                - Show this help
[green]/exit[/green]                - Quit

[yellow]EXAMPLES:[/yellow]
/gen AI-powered legal document automation SaaS
/analyze cryptocurrency trading bot business
/code a complete REST API for content management
/project myapp fastapi
"""
        console.print(help_text)
    
    def _show_models(self):
        """Show available models"""
        table = Table(title="Available AI Models")
        table.add_column("Provider", style="cyan")
        table.add_column("Model", style="green")
        table.add_column("Speed", style="yellow")
        table.add_column("Power", style="magenta")
        
        table.add_row("groq", "llama-3.3-70b-versatile", "⚡⚡⚡", "💪💪💪")
        table.add_row("anthropic", "claude-sonnet-4", "⚡⚡", "💪💪💪💪")
        table.add_row("openai", "gpt-4-turbo", "⚡⚡", "💪💪💪")
        table.add_row("ollama", "llama3.3:70b (local)", "⚡", "💪💪💪")
        
        console.print(table)
    
    def _extract_code(self, response: str):
        """Extract code blocks and save to files"""
        import re
        
        # Find code blocks
        code_pattern = r'```(\w+)?\n(.*?)```'
        matches = re.findall(code_pattern, response, re.DOTALL)
        
        if matches:
            console.print(f"\n[yellow]Found {len(matches)} code block(s)[/yellow]")
            for i, (lang, code) in enumerate(matches, 1):
                if len(code.strip()) > 50:  # Only save substantial code
                    ext = lang if lang else "txt"
                    filename = f"generated_code_{i}.{ext}"
                    
                    save = console.input(f"Save to {filename}? (y/n): ").lower()
                    if save == 'y':
                        Path(filename).write_text(code.strip())
                        console.print(f"[green]✓ Saved to {filename}[/green]")


@click.group()
def main():
    """Mastermind AI - Ultimate Edition"""
    pass


@main.command()
@click.option('--provider', '-p', default='groq', help='AI provider (groq/anthropic/openai/ollama)')
@click.option('--model', '-m', help='Specific model name')
def repl(provider, model):
    """Start interactive REPL"""
    REPL(provider=provider, model=model).run()


@main.command()
@click.argument('prompt')
@click.option('--provider', '-p', default='groq')
@click.option('--model', '-m', help='Model name')
def chat(prompt, provider, model):
    """One-shot chat"""
    ai = MastermindAI(provider=provider, model=model)
    with console.status("[green]Thinking...", spinner="dots"):
        response = ai.chat(prompt)
    console.print(Panel(Markdown(response), title="💎 Mastermind"))


@main.command()
def doctor():
    """System health check"""
    console.print("\n[bold cyan]💊 Mastermind AI Health Check[/bold cyan]\n")
    
    table = Table()
    table.add_column("Component", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Notes", style="yellow")
    
    # Python
    table.add_row("Python", f"✓ {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}", "")
    
    # Groq
    groq_key = os.getenv("GROQ_API_KEY")
    table.add_row("Groq API", "✓ Set" if groq_key else "✗ Not set", "Fast & Free" if groq_key else "Set GROQ_API_KEY")
    
    # Anthropic
    anth_key = os.getenv("ANTHROPIC_API_KEY")
    table.add_row("Anthropic", "✓ Set" if anth_key else "✗ Not set", "Most capable" if anth_key else "Optional")
    
    # OpenAI
    openai_key = os.getenv("OPENAI_API_KEY")
    table.add_row("OpenAI", "✓ Set" if openai_key else "✗ Not set", "Industry standard" if openai_key else "Optional")
    
    # Ollama
    try:
        import requests
        r = requests.get("http://localhost:11434/api/tags", timeout=1)
        if r.status_code == 200:
            models = r.json().get("models", [])
            table.add_row("Ollama", f"✓ Running ({len(models)} models)", "Local inference")
        else:
            table.add_row("Ollama", "✗ Not running", "Run: ollama serve")
    except:
        table.add_row("Ollama", "✗ Not available", "Optional")
    
    # Status
    if groq_key or anth_key or openai_key:
        table.add_row("Overall", "✅ READY TO BUILD!", "Let's make billions!")
    else:
        table.add_row("Overall", "⚠️ Need API key", "Set at least one API key")
    
    console.print(table)
    
    if not (groq_key or anth_key or openai_key):
        console.print("\n[yellow]🔑 Setup Instructions:[/yellow]")
        console.print("1. Get free Groq API: https://console.groq.com")
        console.print("2. Set key: export GROQ_API_KEY='your-key'")
        console.print("3. Run: python mastermind-cli.py repl\n")


@main.command()
@click.argument('name')
@click.option('--template', '-t', default='fastapi', help='Project template')
def create(name, template):
    """Create new project"""
    ai = MastermindAI()
    result = ai.create_project(name, template)
    console.print(f"[green]{result}[/green]")


@main.command()
def history():
    """Show conversation history"""
    ai = MastermindAI()
    if ai.history_file.exists():
        with open(ai.history_file, 'r') as f:
            lines = f.readlines()[-10:]  # Last 10
            for line in lines:
                entry = json.loads(line)
                console.print(f"\n[cyan]{entry['timestamp']}[/cyan] - {entry['provider']}")
                console.print(f"[yellow]Q:[/yellow] {entry['prompt'][:100]}...")
                console.print(f"[green]A:[/green] {entry['response'][:100]}...")
    else:
        console.print("[yellow]No history yet[/yellow]")


if __name__ == "__main__":
    main()